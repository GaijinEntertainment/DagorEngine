
void main(float4 col : TEXCOORD0, out float4 o_color : COLOR)
{ 
  o_color = col;
}
