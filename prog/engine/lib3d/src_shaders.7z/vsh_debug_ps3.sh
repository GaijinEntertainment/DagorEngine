
float4x4 matrix: register(c252);
float color: register(c467);

void main(float4 pos : POSITION, uniform float4 color,
  out float4 o_pos:POSITION, out float4 o_tc0:TEXCOORD0)
{
  o_pos = mul(matrix, pos); 
  o_tc0 = color;
}
