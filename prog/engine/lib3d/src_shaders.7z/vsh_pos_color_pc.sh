  vs_1_1
  dcl_position v0
  dcl_color v1
  dp4 r0.x, v0, c252
  dp4 r0.y, v0, c253
  dp4 r0.z, v0, c254
  dp4 r0.w, v0, c255
  mov oPos, r0
  mov oD0, v1
