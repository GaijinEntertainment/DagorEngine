TIFFstrip
=========

Synopsis
--------

.. highlight:: c

::

    #include <tiffio.h>

.. c:function:: uint32_t TIFFDefaultStripSize(TIFF* tif, uint32_t estimate)

.. c:function:: tmsize_t TIFFStripSize(TIFF* tif)

.. c:function:: tmsize_t TIFFVStripSize(TIFF* tif, uint32_t nrows)

.. c:function:: tmsize_t TIFFRawStripSize(TIFF* tif, uint32_t strip)

.. c:function:: tstrip_t TIFFComputeStrip(TIFF* tif, uint32_t row, tsample_t sample)

.. c:function:: tstrip_t TIFFNumberOfStrips(TIFF* tif)

Description
-----------

:c:func:`TIFFDefaultStripSize` returns the number of rows for a
reasonable-sized strip according to the current settings of the
``ImageWidth``, ``BitsPerSample`` and ``SamplesPerPixel``,
tags and any compression-specific requirements. If the *estimate*
parameter, sf non-zero, then it is taken as an estimate of the desired strip
size and adjusted according to any compression-specific requirements. The
value returned by this function is typically used to define the
``RowsPerStrip`` tag. In lieu of any unusual requirements
``TIFFDefaultStripSize`` tries to create strips that have approximately
8 kilobytes of uncompressed data.

:c:func:`TIFFStripSize` returns the equivalent size for a strip of data
as it would be returned in a call to :c:func:`TIFFReadEncodedStrip`
or as it would be expected in a call to :c:func:`TIFFWriteEncodedStrip`.

:c:func:`TIFFVStripSize` returns the number of bytes in a strip with
*nrows* rows of data.

:c:func:`TIFFRawStripSize` returns the number of bytes in a raw strip
(i.e. not decoded).

:c:func:`TIFFComputeStrip` returns the strip that contains the specified
coordinates. A valid strip is always returned; out-of-range coordinate
values are clamped to the bounds of the image. The *row* parameter is
always used in calculating a strip. The *sample* parameter is used only
if data are organized in separate planes (``PlanarConfiguration`` = 2).

:c:func:`TIFFNumberOfStrips` returns the number of strips in the image.

Diagnostics
-----------

None.

See also
--------

:doc:`TIFFReadEncodedStrip` (3tiff),
:doc:`TIFFReadRawStrip` (3tiff),
:doc:`TIFFWriteEncodedStrip` (3tiff),
:doc:`TIFFWriteRawStrip` (3tiff),
:doc:`libtiff` (3tiff),
